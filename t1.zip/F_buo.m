function f=F_buo(V)
% 计算浮力
ruo_sea=1.025*10^3;
g=9.8;
f=ruo_sea*g*V;
end