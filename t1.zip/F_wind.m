function F = F_wind(x)
%F_WIND 计算风力
%   在此函数内部修改风速
%   输入吃水深度x（水下部分）
S=2*(2-x);
v=12;% 此处修改速度
F=0.625*S*v^2;
end

