function [] = drawpic(angle_guan,angle_tong,angle_mao,len,x,vwind,m)
%DRAWPIC
% angle_guan表示4根钢管倾斜的角度，表示与海平面的交角
% angle_tong表示桶倾斜的角度，与海平面的交角
% angle_mao表示锚链倾斜的角度
rectangle('Position',[-2,0,2,2],'FaceColor','#FFFFFF','EdgeColor','k','Curvature',0.5);
x_pre=0;
y_pre=0;
x_next=0;
y_next=0;
% 锚链的形状
for i=length(angle_mao):-1:1
    x_next=x_pre+len*cos(angle_mao(i));
    y_next=y_pre+len*sin(angle_mao(i));
    line([x_pre x_next],[y_pre,y_next],'LineWidth',2);
    hold on
    x_pre=x_next;
    y_pre=y_next;
end
line([x_next x_next],[y_next y_next-3],'LineWidth',1,'Color','k');

rectangle('position',[x_next-0.5,y_next-3.5,1,1],'curvature',[1,1],'FaceColor','k');
%桶的形状
x_next=x_pre+1*sind(angle_tong);
y_next=y_pre+1*cosd(angle_tong);
line([x_pre x_next],[y_pre,y_next],'LineWidth',8,'Color','#808080');
x_pre=x_next;
y_pre=y_next;

%钢管的形状
for i=length(angle_guan):-1:1
    x_next=x_pre+cos(angle_guan(i));
    y_next=y_pre+sin(angle_guan(i));
    line([x_pre x_next],[y_pre,y_next],'LineWidth',4,'Color','#D3D3D3');
    scatter(x_next,y_next,'black','filled');
    hold on
    x_pre=x_next;
    y_pre=y_next;
end

% 浮标的形状
rectangle('Position',[x_next-1,y_next,2,2]);
hold on
% 水面
line([-5,20],[18,18],'Color','blue');
% 标题与风速
title(['风速为',num2str(vwind),'m/s','重球质量为',num2str(m),'kg']);
end

