function n0 = judge(x,M,L,len,lamda)
%JUDGE
%  n0 表示未被拉起的锚链个数
g=9.8;
g2=(7.9-1.025)/7.9*9.8;
sumF= F_buo(pi*x)+4*F_buo(pi*(0.025)^2*1)+F_buo(1*(0.15^2)*pi);
%-(L/len-n)*L*lamda*g2-1000*g-4*10*g-100*g-1200*g2;
sumG=1000*g+4*10*g+100*g+M*g2;

n0=L/len-(sumF-sumG)/(g2*len*lamda);

end

