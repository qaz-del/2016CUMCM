% 用于保存结果
best_t_angle=5;
best_angle=zeros(4,1);
best_x=0;
H=18;
err=99;

% 长度
L=22.05;

% 每段锚链长度
ll=[0.078,0.105,0.120,0.150,0.180];
% 锚链线密度
lamda=[3.2,7,12.5,19.5,28.12];

N=round(L/ll(2));

%每段锚链下端拉力与海底平面的交角
a_best=zeros(N,1);
%每段锚链的姿态角
phi_best=zeros(N,1);
T_l_best=zeros(N,1);

% 为了缩小搜索范围，采用x_min为够浮标上浮的吃水深度，x_max为所有物体的吃水深度
x_min=1000/(pi*1025);
x_max=(1000+1200+4*10+100+L*lamda(2))/(pi*1025);
% err_arr=[];
x_min=0.31;
x_max=0.77;
for x=x_min:0.001:x_max

   n0=round(judge(x,1200,L,ll(2),lamda(2)));
   if n0>N
        % disp("F_buo is too big");
        continue;
   end
   if n0>0
        n_float=N-n0;
   else 
       n_float=N;
   end
   [T1,a1]=solve_buo(x);

    % 4根钢管
   [phi1,T2,a2]=solve_gangguan(T1,a1);
   [phi2,T3,a3]=solve_gangguan(T2,a2);
   [phi3,T4,a4]=solve_gangguan(T3,a3);
   [phi4,T5,a5]=solve_gangguan(T4,a4);

    % 钢桶
    M_qiu=1200;
    [phi_tong,T6,a6]=solve_gangtong(T5,a5,M_qiu);
    
%     if 90-phi_tong/pi*180>5
%         continue
%     end


    %每段锚链下端的拉力
    T_l=zeros(N,1);
    %每段锚链下端拉力与海底平面的交角
    a_l=zeros(N,1);
    %每段锚链的姿态角
    phi_l=zeros(N,1);

    % 算出底端的拉力和倾角
    m_lian=ll(2)*lamda(2);
    [phi_l(1),T_l(1),a_l(1)]=solve_lian(T6,a6,m_lian);
    for k=2:n_float
        [phi_l(k),T_l(k),a_l(k)]=solve_lian(T_l(k-1),a_l(k-1),m_lian);
        if phi_l(k)<0
            break
        end
    end
    phi_l(k:end)=0;
    if a_l(N)/pi*180>16
        continue
    end

%     if 90-phi_tong/pi*180<best_t_angle
%         best_t_angle=90-phi_tong/pi*180;
%         best_angle(1)=phi1;
%         best_angle(2)=phi2;
%         best_angle(3)=phi3;
%         best_angle(4)=phi4;
%         best_x=x;
%         
%     end
%     err_arr=[err_arr abs(x+sin(a2)+sin(a3)+sin(a4)+sin(a5)+sin(a6)+ll(2)*sum(sin(phi_l))-H)];
    if abs(x+sin(a2)+sin(a3)+sin(a4)+sin(a5)+sin(a6)+ll(2)*sum(sin(phi_l))-H)<err
        err=abs(x+sin(a2)+sin(a3)+sin(a4)+sin(a5)+sin(a6)+ll(2)*sum(sin(phi_l))-H);
        best_t_angle=90-phi_tong/pi*180;
        best_angle(1)=phi1;
        best_angle(2)=phi2;
        best_angle(3)=phi3;
        best_angle(4)=phi4;
        best_x=x;
        a_best=a_l;
        phi_best=phi_l;
        T_l_best=T_l;
    end
end


% 游走半径
h=sum(sin(phi_best))*ll(2)+sum(sin(best_angle))+sin(best_t_angle);
r=sum(cos(phi_best))*ll(2)+sum(cos(best_angle))+cos(best_t_angle);


% 验证是否存在锚链落地的情况

% 最优解的四根钢管角度保存在best_angle中
% 最优解的桶的角度保存在best_t_angle中
% 最优解的锚链的各段的角度在phi_l中
% 
drawpic(best_angle,best_t_angle,phi_best,ll(2),best_x,12,1200);


