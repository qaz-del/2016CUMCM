function [T1,alpha1] = solve_buo(x)
% 浮标受力分析的求解函数
% 我们发现，输入一个x，在浮标方程组可以求得T1和alpha1，代入后续方程可以完成求解
M=1000;
V_b=pi*x;
g=9.8;
alpha1=atan((F_buo(V_b)-M*g)/F_wind(x));
T1=sqrt(F_wind(x)^2+(F_buo(V_b)-M*g)^2);
end

