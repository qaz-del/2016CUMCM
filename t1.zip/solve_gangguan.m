function [phi_i,T_next,alpha_next] = solve_gangguan(T_last,alpha_last)
% 求解钢管的函数
% 根据两个方向的受力以及一个力矩平衡，可以通过已知的两个参数求解出
% 输入上一根绳的拉力和角度，求解这一根绳的拉力，拉力方向，姿态角度
m=10;
g=9.8;
V=pi*(0.025)^2*1;
A=T_last*cos(alpha_last);
B=T_last*sin(alpha_last)+F_buo(V)-m*g;
alpha_next=abs(atan(B/A));
T_next=sqrt(A^2+B^2);

equ_mo=@(phi) (m*g-F_buo(V))*1*cos(phi)-2*T_last*sin(phi-alpha_last);
phi_i=fsolve(equ_mo,0);
end

