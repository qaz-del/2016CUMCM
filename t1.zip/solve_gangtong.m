function [phi_i,T_next,alpha_next] = solve_gangtong(T_last,alpha_last,M)
% 求解钢桶状态的函数
% 钢桶与钢管状态类似
% 但是之后要加球，可能会有不同，故分开来写

m=100;
g=9.8;
V=1*(0.15^2)*pi;
A=T_last*cos(alpha_last);
B=T_last*sin(alpha_last)+F_buo(V)-m*g-M*g*(7.9-1.025)/7.9;
alpha_next=abs(atan(B/A));
T_next=sqrt(A^2+B^2);

equ_mo=@(phi) (m*g-F_buo(V))*1*cos(phi)-2*T_last*sin(phi-alpha_last);
phi_i=fsolve(equ_mo,0);
end

