function [phi_i,T_next,alpha_next] = solve_lian(T_last,alpha_last,m_lian)
% 求解最终的压力
% 是按段来计算的
g=9.8*(7.9-1.025)/7.9;
A=T_last*cos(alpha_last);
B=T_last*sin(alpha_last)-m_lian*g;
alpha_next=abs(atan(B/A));
T_next=sqrt(A^2+B^2);

equ_mo=@(phi) (m_lian*g)*cos(phi)-2*T_last*sin(phi-alpha_last);
phi_i=fsolve(equ_mo,0);
end

