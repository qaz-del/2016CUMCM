function [] = drawpic3(r_guan,r_mao,r_tong,x,len,vwind,v_water,Mqiu,N)
%DRAWPIC3 此处显示有关此函数的摘要
r_pre=[0,0,0];
r_next=[0,0,0];
for i=N:-1:1
    r_next=r_pre+r_mao(i,1:3);
    plot3([r_pre(1),r_next(1)],[r_pre(2),r_next(2)],[r_pre(3),r_next(3)],'LineWidth',2,'Color','b');
    hold on
    r_pre=r_next;
end

r_next=r_pre+r_tong;
plot3([r_pre(1),r_next(1)],[r_pre(2),r_next(2)],[r_pre(3),r_next(3)],'LineWidth',8,'Color','#808080');
hold on
r_pre=r_next;

for i=4:-1:1
    r_next=r_pre+r_guan(i,1:3);
    plot3([r_pre(1),r_next(1)],[r_pre(2),r_next(2)],[r_pre(3),r_next(3)],'LineWidth',2,'Color','#D3D3D3');
    scatter3(r_next(1),r_next(2),r_next(3),'black','filled');
    hold on
    r_pre=r_next;
end
title("风速为"+num2str(vwind)+"水速为"+num2str(v_water));
%hold off
end

