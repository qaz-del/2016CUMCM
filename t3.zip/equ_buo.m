function q = equ_buo(T,x,alpha,v_water,v_wind)
%BUO_EQU 此处显示有关此函数的摘要
F_w=F_water(x*2,v_water);
F_f=F_wind(x,v_wind);
%重力与浮力的合力（0，0，F_buo(x)-Mg)
%拉力（T（1）,T(2),T(3))
%水力 (F_w,0,0)
%风力 (F_f*cos(alpha),F_f*sin(alpha),0)
%不妨假设在分量在y轴正向
q(1)=T(1)+F_w+F_f*cos(alpha);
q(2)=T(2)+F_f*sin(alpha);
q(3)=F_buo(pi*x)-1000*9.8+T(3);
end

