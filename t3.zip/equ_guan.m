function q = equ_guan(res,T_last,v_water)
%GUAN_EQU 
%  
G=10*9.8;
F_b=F_buo(pi*(0.025)^2*1);
F_w=F_water(sqrt(1-sqrt(res(1)^2))*0.05,v_water);
% 竖直方向合力(0,0,F_b-G)
% 水的作用力(F_w,0,0)
% 上一段的拉力(T_last(1),T_last(2),T_last(3))
% 待求的拉力(T(1),T(2),T(3))
%受力平衡
q(1)=F_w+T_last(1)+res(4);
q(2)=T_last(2)+res(5);
q(3)=F_b-G+T_last(3)+res(6);

%力矩平衡
r=res(1:3);
%M=cross([0,0,F_b-G],r*0.5)+cross([F_w,0,0],r*0.5)+cross(T_last,r);
% q(4)=M(1);
% q(5)=M(2);
q(4)=(T_last(3)+0.5*(F_b-G))*res(1)-(0.5*F_w+T_last(1))*res(3);
q(5)=(0.5*F_w+T_last(1))*res(2)-T_last(2)*res(1);
q(6)=norm(r)-1;
end

