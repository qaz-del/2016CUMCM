
function q = equ_mao(res,T_last,v_water,len,lamda)
% equ_mao
%  
G=len*lamda*9.8*(7.9-1.025)/7.9;
% 竖直方向合力(0,0,-G)
% 水的作用力(F_w,0,0)
% 上一段的拉力(T_last(1),T_last(2),T_last(3))
% 待求的拉力(T(1),T(2),T(3))
%受力平衡
q(1)=T_last(1)+res(4);
q(2)=T_last(2)+res(5);
q(3)=-G+T_last(3)+res(6);

%力矩平衡
r=res(1:3);
% M=cross([0,0,-G],r*0.5)+cross([F_w,0,0],r*0.5)+cross(T_last,r);
% q(4)=M(1);
% q(5)=M(2);
q(4)=(T_last(3)+0.5*(-G))*res(1)-(T_last(1))*res(3);
q(5)=(T_last(1))*res(2)-T_last(2)*res(1);
q(6)=norm(r)-len;
end

