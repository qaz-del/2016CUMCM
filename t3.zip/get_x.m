function [final_r_guan,final_r_tong,final_r_mao,final_x,r_youdong,phi_tong,beta,error] = get_x(v_wind,H,Mqiu,kind,L,v_water,alpha)
%GET_X 
% INPUT
%     vwind  风速
%     H  深度
%     Mqiu  重球重量
%     kind  锚链种类
%     L 锚链长度
%     v_water 水速
%     alpha   水速与风速夹角

% OUTPUT
%  final_r_guan  钢管的状态
%  final_r_tong  钢桶的状态
%  final_r_mao   锚链的状态
%  final_x       吃水深度
%  r_youdong     游动半径
%  phi_tong      桶与竖直方向的夹角
%  err           总高度与水深的插值

% 每段锚链长度
ll=[0.078,0.105,0.120,0.150,0.180];
% 锚链线密度
lamda=[3.2,7,12.5,19.5,28.12];

    N=round(L/ll(kind));
    err=99;
    final_r_guan=zeros(4,3);
    final_r_tong=zeros(1,3);
    final_r_mao=zeros(N,3);
    final_x=0;
    x_min=1000/(pi*1025);
    x_max=(1000+1200+4*10+100+L*lamda(2)+Mqiu)/(pi*1025);
    for x=x_min:0.005:min(x_max,2)
         n0=round(judge(x,Mqiu,L,ll(kind),lamda(kind)));
        if n0>=N
            continue
        end
        if n0<N && n0>0
            n_float=N-n0;
        end
    
        t_flag=1;
        if n0<=0
            n_float=N;
        end
        T1=solve_buo_3(x,alpha,v_water,v_wind);
        r_guan=zeros(4,3);
        T_guan=zeros(4,3);
        [r_guan(1,1:3),T_guan(1,1:3),flag]=solve_gangguan_3(T1,v_water);
    %      if flag<0
    %         continue
    %      end
        for i=2:4
            [r_guan(i,1:3),T_guan(i,1:3),flag]=solve_gangguan_3(T_guan(i-1,1:3),v_water);
              if flag<0
                    tflag=0;
                    break;
              end
        end
        
        [r_tong,T_tong,flag]=solve_gangtong_3(T_guan(4,:),v_water,Mqiu);
    %     if flag<0
    %         continue
    %     end
    %     if asind(sqrt(1-r_tong(3)^2))>5
    %         continue
    %     end
        r_mao=zeros(N,3);
        T_mao=zeros(N,3);
        [r_mao(1,1:3),T_mao(1,1:3)]=solve_mao_3(T_tong,ll(kind),lamda(kind));
    %     if flag<0
    %         continue
    %     end
        for k=2:n_float
            [r_mao(k,1:3),T_mao(k,1:3)]=solve_mao_3(T_mao(k-1,1:3),ll(kind),lamda(kind));
        end
        for k=n_float+1:N
            r_mao(k,1:3)=[r_mao(n_float,1),r_mao(n_float,2),0];
        end
        if atand(-T_mao(N,3)/sqrt(T_mao(N,1)^2+T_mao(N,2)^2))>16
            continue
        end
        dh=abs(sum(r_mao(:,3))+sum(r_guan(:,3))+r_tong(3)+x-H);
        if dh<err 
            err=dh;
            final_r_mao=r_mao;
            final_r_tong=r_tong;
            final_r_guan=r_guan;
            final_x=x;
            if(n0<0)
                beta=-atand(T_mao(N,3)/sqrt(T_mao(N,1)^2+T_mao(N,2)^2));
            else 
                beta=0;
            end
            error=dh;
    
        end
    end
    % 在final系列变量中保存了这组解
    dx=sum(final_r_guan(:,1))+sum(final_r_tong(:,1))+sum(final_r_mao(:,1));
    dy=sum(final_r_guan(:,2))+sum(final_r_tong(:,2))+sum(final_r_mao(:,2));
    r_youdong=sqrt(dx^2+dy^2);
    phi_tong=acosd(final_r_tong(:,3));
    drawpic3(final_r_guan,final_r_mao,final_r_tong,final_x,ll(kind),v_wind,v_water,Mqiu,N);