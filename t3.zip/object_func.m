function opt= object_func(phi_tong,phi_l,phi1,phi2,phi3,phi4,len)
%OBJECT_FUNC 此处显示有关此函数的摘要
r=cos(pi*0.5-phi_tong)+cos(phi1)+cos(phi2)+cos(phi3)+cos(phi4)+len*sum(cos(phi_l));
opt=r+10*phi_tong;
end

