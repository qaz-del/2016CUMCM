function T = solve_buo_3(x,alpha,v_water,v_wind)
%SOLVE_BUO_3 
% x为沉入水中的高度，alpha为水流与风向的角度,v_wind为风速，v_water为水速
T=fsolve(@(T)equ_buo(T,x,alpha,v_water,v_wind),[0,0,0]);
end

