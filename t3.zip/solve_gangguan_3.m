function [r,T,exitflag] = solve_gangguan_3(T_last,v_water)
%SOLVE_GANGGUAN_3 此处显示有关此函数的摘要
%   r为姿态角，即（x,y,z)
% 注意，由于作用力与反作用力，T取反
%options.Algorithm = "levenberg-marquardt";
options.StepTolerance = 1.000000e-03;
[res,fval,exitflag]=fsolve(@(res) equ_guan(res,-T_last,v_water),[0.1 0.1 0.7 -T_last(1) -T_last(2) -T_last(3)],options);
r=res(1:3);
T=res(4:6);
for i=1:3
    if r(i)<10^-6
        r(i)=0;
    end
end
end

