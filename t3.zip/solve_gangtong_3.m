function [r,T,exitflag] = solve_gangtong_3(T_last,v_water,M_qiu)
%SOLVE_GANGTONG_3 此处显示有关此函数的摘要
%   此处显示详细说明
%   r为姿态角，即（x,y,z)
% 注意，由于作用力与反作用力，T取反
options = optimoptions('fsolve');
options.StepTolerance=1e-12;
options.FunctionTolerance=1e-20;
options.OptimalityTolerance=1e-8;
[res,fval,exitflag]=fsolve(@(res) equ_tong(res,-T_last,v_water,M_qiu),[0 0 1 -T_last(1) -T_last(2) -T_last(3)],options);
if(~isreal(res))
    exitflag=-1;
end
r=res(1:3);
T=res(4:6);
for i=1:3
    if r(i)<10^-4
        r(i)=0;
    end
end
disp(fval);
end

