function [r,T] = solve_mao_3(T_last,len,lamda)
%SOLVE_LIAN_3 此处显示有关此函数的摘要
%   此处显示详细说明

G=len*lamda*9.8*(7.9-1.025)/7.9;
T(1)=T_last(1);
T(2)=T_last(2);
T(3)=G+T_last(3);

A=(T_last(3)+0.5*(G));
B=T_last(1);
C=T_last(1);
D=T_last(2);

r(1)=len/sqrt(1+(A/B)^2+(D/C)^2);
r(2)=D/C*r(1);
r(3)=A/B*r(1);
% options = optimoptions('fsolve');
% options.StepTolerance=1e-6;
% options.FunctionTolerance=1e-6;
% options.MaxFunctionEvaluations=1000;
% [res,fval,exitflag]=fsolve(@(res) equ_mao(res,-T_last,v_water,len,lamda),[len/2 0 len/2 -T_last(1) -T_last(2) -T_last(3)],options);
% r=res(1:3);
% T=res(4:6);
% for i=1:3
%     if r(i)<10^-4
%         r(i)=0;
%     end
% end

end
